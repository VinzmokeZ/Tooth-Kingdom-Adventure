import React, { useState } from 'react';
import { PhoneFrame } from './components/PhoneFrame';
import { AppScreens } from './components/AppScreens';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('signin');
  const [userData, setUserData] = useState({
    selectedCharacter: null as number | null,
    currentStreak: 7,
    totalDays: 45,
    completedChapters: 2,
    totalStars: 127,
    level: 5,
    achievements: [1, 2, 3, 4],
    unlockedRewards: [1, 2, 3, 4, 5],
  });

  const navigateTo = (screen: string) => {
    setCurrentScreen(screen);
  };

  const updateUserData = (updates: Partial<typeof userData>) => {
    setUserData(prev => ({ ...prev, ...updates }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-blue-50 to-pink-100 flex items-center justify-center p-8">
      <PhoneFrame>
        <AppScreens
          currentScreen={currentScreen}
          navigateTo={navigateTo}
          userData={userData}
          updateUserData={updateUserData}
        />
      </PhoneFrame>
    </div>
  );
}