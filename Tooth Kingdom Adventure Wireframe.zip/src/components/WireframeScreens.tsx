import React from 'react';
import { SplashScreen } from './screens/SplashScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { CharacterSelectScreen } from './screens/CharacterSelectScreen';
import { DashboardScreen } from './screens/DashboardScreen';
import { ChaptersScreen } from './screens/ChaptersScreen';
import { BrushingLessonScreen } from './screens/BrushingLessonScreen';
import { RewardsScreen } from './screens/RewardsScreen';
import { ProgressScreen } from './screens/ProgressScreen';
import { CalendarScreen } from './screens/CalendarScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { AchievementsScreen } from './screens/AchievementsScreen';
import { StatsScreen } from './screens/StatsScreen';
import { NotificationsScreen } from './screens/NotificationsScreen';
import { StreakScreen } from './screens/StreakScreen';

interface WireframeScreensProps {
  currentScreen: string;
  navigateTo: (screen: string) => void;
  selectedCharacter: number | null;
  setSelectedCharacter: (char: number | null) => void;
  scrollPosition: number;
  setScrollPosition: (pos: number) => void;
}

export function WireframeScreens({
  currentScreen,
  navigateTo,
  selectedCharacter,
  setSelectedCharacter,
  scrollPosition,
  setScrollPosition
}: WireframeScreensProps) {
  const screenProps = { navigateTo, selectedCharacter, setSelectedCharacter, scrollPosition, setScrollPosition };

  switch (currentScreen) {
    case 'splash':
      return <SplashScreen {...screenProps} />;
    case 'onboarding':
      return <OnboardingScreen {...screenProps} />;
    case 'character-select':
      return <CharacterSelectScreen {...screenProps} />;
    case 'dashboard':
      return <DashboardScreen {...screenProps} />;
    case 'chapters':
      return <ChaptersScreen {...screenProps} />;
    case 'brushing-lesson':
      return <BrushingLessonScreen {...screenProps} />;
    case 'rewards':
      return <RewardsScreen {...screenProps} />;
    case 'progress':
      return <ProgressScreen {...screenProps} />;
    case 'calendar':
      return <CalendarScreen {...screenProps} />;
    case 'settings':
      return <SettingsScreen {...screenProps} />;
    case 'profile':
      return <ProfileScreen {...screenProps} />;
    case 'achievements':
      return <AchievementsScreen {...screenProps} />;
    case 'stats':
      return <StatsScreen {...screenProps} />;
    case 'notifications':
      return <NotificationsScreen {...screenProps} />;
    case 'streak':
      return <StreakScreen {...screenProps} />;
    default:
      return <SplashScreen {...screenProps} />;
  }
}
