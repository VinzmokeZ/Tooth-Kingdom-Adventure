import React from 'react';
import { ScreenProps } from './types';
import { ChevronLeft, Edit2, Award, Calendar, TrendingUp, Star, Trophy, Flame, Share2 } from 'lucide-react';
import { UserAvatar, getCharacterName } from '../common/UserAvatar';

export function ProfileScreen({ navigateTo, userData }: ScreenProps) {
  return (
    <div className="h-full bg-gradient-to-b from-purple-50 to-white flex flex-col">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-br from-purple-500 to-purple-600 text-white px-5 pt-5 pb-8 z-10 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <button onClick={() => navigateTo('dashboard')} className="p-2 -ml-2">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">My Profile</h1>
          <button className="p-2 -mr-2">
            <Edit2 className="w-5 h-5" />
          </button>
        </div>

        {/* Profile card */}
        <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-6 border border-white/30">
          <div className="flex flex-col items-center text-center mb-4">
            {/* Enhanced character avatar with glow effect */}
            <div className="relative mb-4 animate-float-gentle">
              <UserAvatar 
                characterId={userData.selectedCharacter} 
                size="xlarge" 
                className="shadow-2xl" 
              />
              {/* Glow ring */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 blur-xl opacity-40 animate-pulse"></div>
            </div>
            <h2 className="text-2xl font-bold mb-1">
              {getCharacterName(userData.selectedCharacter)} the Champion 🏆
            </h2>
            <p className="text-white/80 text-sm">Joined January 2026</p>
          </div>

          <div className="flex items-center justify-center gap-2 bg-white/20 backdrop-blur-sm rounded-2xl p-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-purple-400 rounded-lg flex items-center justify-center font-bold text-sm shadow-md">
                {userData.level}
              </div>
              <span className="text-sm font-medium">Level {userData.level}</span>
            </div>
            <div className="w-px h-6 bg-white/30"></div>
            <div className="flex items-center gap-1">
              <Star className="w-5 h-5 fill-yellow-300 text-yellow-300" />
              <span className="font-bold">{userData.totalStars}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-5 py-5 space-y-5">
        {/* Stats overview */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { icon: Trophy, value: userData.totalStars, label: 'Total Stars', color: 'from-amber-400 to-orange-500' },
            { icon: Flame, value: userData.currentStreak, label: 'Day Streak', color: 'from-orange-400 to-pink-500' },
            { icon: Calendar, value: userData.totalDays, label: 'Total Days', color: 'from-blue-400 to-cyan-500' },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div key={i} className="bg-white rounded-2xl p-4 shadow-md text-center">
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl mb-2 flex items-center justify-center mx-auto shadow-md`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-xs text-gray-500 mt-1">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* Quick links */}
        <div className="space-y-3">
          <button
            onClick={() => navigateTo('achievements')}
            className="w-full flex items-center gap-4 p-4 bg-white rounded-3xl shadow-md hover:shadow-lg transition-all"
          >
            <div className="w-14 h-14 bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center shadow-md">
              <Award className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold text-gray-900 mb-1">Achievements</h3>
              <p className="text-sm text-gray-500">{userData.achievements.length} unlocked badges</p>
            </div>
            <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center font-bold text-amber-600">
              {userData.achievements.length}
            </div>
          </button>

          <button
            onClick={() => navigateTo('stats')}
            className="w-full flex items-center gap-4 p-4 bg-white rounded-3xl shadow-md hover:shadow-lg transition-all"
          >
            <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-2xl flex items-center justify-center shadow-md">
              <TrendingUp className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold text-gray-900 mb-1">Statistics</h3>
              <p className="text-sm text-gray-500">View your progress & insights</p>
            </div>
          </button>

          <button
            onClick={() => navigateTo('calendar')}
            className="w-full flex items-center gap-4 p-4 bg-white rounded-3xl shadow-md hover:shadow-lg transition-all"
          >
            <div className="w-14 h-14 bg-gradient-to-br from-green-400 to-emerald-500 rounded-2xl flex items-center justify-center shadow-md">
              <Calendar className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold text-gray-900 mb-1">Activity Calendar</h3>
              <p className="text-sm text-gray-500">Track your daily progress</p>
            </div>
          </button>
        </div>

        {/* Recent achievements showcase */}
        <div className="bg-white rounded-3xl p-5 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-900">Recent Achievements</h3>
            <button
              onClick={() => navigateTo('achievements')}
              className="text-purple-600 text-sm font-medium"
            >
              See All
            </button>
          </div>
          
          <div className="grid grid-cols-4 gap-3">
            {[
              { emoji: '🏆', name: 'Master', color: 'from-amber-400 to-orange-500' },
              { emoji: '🔥', name: 'Week', color: 'from-orange-400 to-pink-500' },
              { emoji: '⭐', name: 'First', color: 'from-purple-400 to-purple-600' },
              { emoji: '🎯', name: 'Goal', color: 'from-blue-400 to-cyan-500' },
            ].map((achievement, i) => (
              <div key={i} className="text-center">
                <div className={`w-full aspect-square bg-gradient-to-br ${achievement.color} rounded-2xl mb-2 flex items-center justify-center text-3xl shadow-md`}>
                  {achievement.emoji}
                </div>
                <p className="text-xs text-gray-600 font-medium truncate">{achievement.name}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Progress summary */}
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-3xl p-5 text-white shadow-lg">
          <h3 className="font-bold mb-4">Progress Summary</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm opacity-90">Chapters Completed</span>
              <span className="font-bold">{userData.completedChapters}/5</span>
            </div>
            <div className="h-2 bg-white/20 backdrop-blur-sm rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full"
                style={{ width: `${(userData.completedChapters / 5) * 100}%` }}
              ></div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-sm opacity-90">Rewards Unlocked</span>
              <span className="font-bold">{userData.unlockedRewards.length}/10</span>
            </div>
            <div className="h-2 bg-white/20 backdrop-blur-sm rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full"
                style={{ width: `${(userData.unlockedRewards.length / 10) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Share profile */}
        <button className="w-full h-14 bg-white border-2 border-purple-600 text-purple-600 rounded-2xl font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2">
          <Share2 className="w-5 h-5" />
          Share My Progress
        </button>
      </div>

      <style jsx>{`
        @keyframes float-gentle {
          0%, 100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-10px);
          }
        }
        .animate-float-gentle {
          animation: float-gentle 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}