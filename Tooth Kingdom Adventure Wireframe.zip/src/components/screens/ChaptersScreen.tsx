import React from 'react';
import { ScreenProps } from './types';
import { ChevronLeft, Lock, CheckCircle, Star, ArrowRight } from 'lucide-react';

const chapters = [
  {
    id: 1,
    title: 'The Brushing Basics Adventure',
    description: 'Join our hero at the gates of the Enamel Castle. Learn why we brush and master the ancient circular technique to defeat the Plaque Monsters!',
    lessons: 5,
    stars: 15,
    completed: true,
    locked: false,
    color: 'from-purple-100 to-purple-50',
    illustration: 'https://images.unsplash.com/photo-1649293823459-094749e377d5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJ0b29uJTIwY2FzdGxlJTIwZmFudGFzeSUyMGNoaWxkcmVufGVufDF8fHx8MTc2OTE1MDk3Nnww&ixlib=rb-4.1.0&q=80&w=1080'
  },
  {
    id: 2,
    title: 'The Sugar Bugs Attack',
    description: 'Discover how to fight cavity-causing bacteria and protect your tooth kingdom from the sugar bug invasion!',
    lessons: 6,
    stars: 18,
    completed: true,
    locked: false,
    color: 'from-blue-100 to-blue-50',
    illustration: 'https://images.unsplash.com/photo-1563802287254-0b0a9943d36f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJ0b29uJTIwYnVncyUyMG1vbnN0ZXJzJTIwY3JlYXR1cmVzfGVufDF8fHx8MTc2OTE1MDk3Nnww&ixlib=rb-4.1.0&q=80&w=1080'
  },
  {
    id: 3,
    title: 'Flossing Adventures',
    description: 'Master the art of flossing between your teeth and unlock secret passages in the Tooth Kingdom!',
    lessons: 5,
    stars: 15,
    completed: false,
    locked: false,
    color: 'from-pink-100 to-pink-50',
    illustration: 'https://images.unsplash.com/photo-1766156555244-572b9757433b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwYWR2ZW50dXJlJTIwbWFnaWNhbCUyMGtpbmdkb218ZW58MXx8fHwxNzY5MTUwOTc3fDA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  {
    id: 4,
    title: 'Healthy Eating Habits',
    description: 'Learn which foods help keep your teeth strong and which ones to avoid in your quest!',
    lessons: 7,
    stars: 21,
    completed: false,
    locked: true,
    color: 'from-green-100 to-green-50',
    illustration: 'https://images.unsplash.com/photo-1568477070631-5bfef06fdf44?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwZnJ1aXRzJTIwdmVnZXRhYmxlcyUyMGNvbG9yZnVsfGVufDF8fHx8MTc2OTE1MDk3N3ww&ixlib=rb-4.1.0&q=80&w=1080'
  },
  {
    id: 5,
    title: 'Tooth Kingdom Master',
    description: 'Become the ultimate dental health champion and earn your crown in the Tooth Kingdom!',
    lessons: 8,
    stars: 24,
    completed: false,
    locked: true,
    color: 'from-amber-100 to-amber-50',
    illustration: 'https://images.unsplash.com/photo-1739323980445-b76a6e459d0b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcm93biUyMHRyb3BoeSUyMGFjaGlldmVtZW50JTIwZ29sZHxlbnwxfHx8fDE3NjkxNTA5ODB8MA&ixlib=rb-4.1.0&q=80&w=1080'
  },
];

export function ChaptersScreen({ navigateTo, userData }: ScreenProps) {
  return (
    <div className="h-full bg-white flex flex-col">
      {/* Header */}
      <div className="bg-white px-5 pt-4 pb-3">
        <div className="flex items-center gap-3 mb-4">
          <button 
            onClick={() => navigateTo('dashboard')} 
            className="p-2 -ml-2 hover:bg-gray-100 rounded-xl transition-all"
          >
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-2xl font-extrabold text-gray-900">Chapters</h1>
        </div>

        {/* Progress summary */}
        <div 
          className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl p-4 text-white"
          style={{
            boxShadow: '0 6px 20px rgba(124, 58, 237, 0.25), 0 2px 8px rgba(124, 58, 237, 0.15)',
          }}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold">Overall Progress</span>
            <span className="text-sm font-bold">{userData.completedChapters}/{chapters.length} Complete</span>
          </div>
          <div className="progress-bar-child" style={{ height: '10px', background: 'rgba(255,255,255,0.2)' }}>
            <div
              className="progress-bar-fill"
              style={{ 
                width: `${(userData.completedChapters / chapters.length) * 100}%`,
                background: 'white',
              }}
            ></div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        {chapters.map((chapter) => (
          <button
            key={chapter.id}
            onClick={() => !chapter.locked && navigateTo('brushing-lesson')}
            disabled={chapter.locked}
            className={`w-full lesson-card text-left ${
              chapter.locked ? 'opacity-60 cursor-not-allowed' : ''
            }`}
          >
            {/* Chapter Badge */}
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-purple-600 bg-purple-50 px-3 py-1.5 rounded-full">
                Chapter {chapter.id}
              </span>
              {!chapter.locked && (
                <div className="flex items-center gap-1.5 bg-amber-50 px-3 py-1.5 rounded-full">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span className="text-xs font-bold text-amber-700">{chapter.stars} stars</span>
                </div>
              )}
              {chapter.completed && (
                <div className="bg-green-50 px-3 py-1.5 rounded-full flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-green-600 fill-green-600" />
                  <span className="text-xs font-bold text-green-700">Completed</span>
                </div>
              )}
            </div>

            {/* Title */}
            <h3 className="text-xl font-extrabold text-gray-900 mb-2 leading-tight">
              {chapter.title}
            </h3>

            {/* Description */}
            <p className="text-gray-600 text-sm leading-relaxed mb-4">
              {chapter.description}
            </p>

            {/* Illustration */}
            <div 
              className={`w-full h-48 bg-gradient-to-br ${chapter.color} rounded-2xl mb-4 overflow-hidden relative`}
              style={{
                boxShadow: '0 4px 16px rgba(0,0,0,0.08), 0 2px 6px rgba(0,0,0,0.04)',
              }}
            >
              <img 
                src={chapter.illustration}
                alt={chapter.title}
                className="w-full h-full object-cover opacity-80"
              />
              {chapter.locked && (
                <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm flex items-center justify-center">
                  <div className="text-center">
                    <Lock className="w-12 h-12 text-white mx-auto mb-2" />
                    <p className="text-white text-sm font-semibold">Complete previous chapters</p>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">
                {chapter.lessons} lessons
              </span>
              {!chapter.locked && (
                <div className="flex items-center gap-2 text-purple-600 font-bold text-sm">
                  Begin Chapter
                  <ArrowRight className="w-4 h-4" />
                </div>
              )}
            </div>

            {/* Progress bar for current chapter */}
            {!chapter.locked && !chapter.completed && chapter.id === 3 && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gray-600 font-medium">Your Progress</span>
                  <span className="text-xs font-bold text-purple-600">2/5 lessons</span>
                </div>
                <div className="progress-bar-child">
                  <div className="progress-bar-fill" style={{ width: '40%' }}></div>
                </div>
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}