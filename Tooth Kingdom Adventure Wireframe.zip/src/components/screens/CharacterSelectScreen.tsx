import React from 'react';
import { ScreenProps } from './types';
import { Check } from 'lucide-react';

const characters = [
  { id: 1, name: 'Luna', color: 'from-purple-400 to-pink-400', image: 'https://images.unsplash.com/photo-1758179760575-deee2f7b518e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGFuaW1lJTIwY2hhcmFjdGVyJTIwcHVycGxlJTIwcGlua3xlbnwxfHx8fDE3NjkxNTE2OTN8MA&ixlib=rb-4.1.0&q=80&w=1080' },
  { id: 2, name: 'Max', color: 'from-blue-400 to-cyan-400', image: 'https://images.unsplash.com/photo-1586374579358-9d19d632b6df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGNoYXJhY3RlciUyMGJveSUyMGJsdWV8ZW58MXx8fHwxNzY5MTUxNjk4fDA&ixlib=rb-4.1.0&q=80&w=1080' },
  { id: 3, name: 'Mia', color: 'from-pink-400 to-rose-400', image: 'https://images.unsplash.com/photo-1603201401293-040c048d7a00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGFuaW1lJTIwZ2lybCUyMGNoYXJhY3RlciUyMHBpbmt8ZW58MXx8fHwxNzY5MTUxNjk0fDA&ixlib=rb-4.1.0&q=80&w=1080' },
  { id: 4, name: 'Zara', color: 'from-amber-400 to-orange-400', image: 'https://images.unsplash.com/photo-1762359853028-e9b61ed96114?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGFuaW1lJTIwY2hhcmFjdGVyJTIwb3JhbmdlJTIwYWN0aW9ufGVufDF8fHx8MTc2OTE1MTY5NXww&ixlib=rb-4.1.0&q=80&w=1080' },
  { id: 5, name: 'Kai', color: 'from-indigo-400 to-purple-400', image: 'https://images.unsplash.com/photo-1639094134125-16f32dfe19cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGFuaW1lJTIwY2hhcmFjdGVyJTIwcHVycGxlJTIwZmFudGFzeXxlbnwxfHx8fDE3NjkxNTE2OTV8MA&ixlib=rb-4.1.0&q=80&w=1080' },
];

export function CharacterSelectScreen({ navigateTo, userData, updateUserData }: ScreenProps) {
  const handleSelect = (charId: number) => {
    updateUserData({ selectedCharacter: charId });
  };

  const handleContinue = () => {
    if (userData.selectedCharacter !== null) {
      navigateTo('dashboard');
    }
  };

  return (
    <div className="h-full bg-gradient-to-b from-purple-50 to-white flex flex-col">
      {/* Header */}
      <div className="p-6 pb-4">
        <h1 className="text-4xl font-extrabold text-center text-gray-900 mb-2 leading-tight">
          Choose Your Hero! 🦷✨
        </h1>
        <p className="text-center text-gray-600 text-base">
          Pick your adventure companion to save the Tooth Kingdom!
        </p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 pb-6">
        <div className="grid grid-cols-2 gap-4">
          {characters.map((char) => (
            <button
              key={char.id}
              onClick={() => handleSelect(char.id)}
              className={`relative p-4 rounded-3xl transition-all transform ${
                userData.selectedCharacter === char.id
                  ? 'ring-4 ring-purple-600 scale-105 bg-white'
                  : 'bg-white hover:scale-105 active:scale-95'
              }`}
              style={{
                boxShadow: userData.selectedCharacter === char.id
                  ? '0 12px 40px rgba(124, 58, 237, 0.25), 0 4px 16px rgba(124, 58, 237, 0.15)'
                  : '0 6px 20px rgba(0,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04)',
              }}
            >
              {/* Character avatar */}
              <div 
                className={`w-full aspect-square bg-gradient-to-br ${char.color} rounded-2xl mb-3 flex items-center justify-center overflow-hidden relative`}
                style={{
                  boxShadow: '0 8px 24px rgba(0,0,0,0.15), 0 4px 12px rgba(0,0,0,0.1)',
                }}
              >
                <img 
                  src={char.image} 
                  alt={char.name}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                  style={{
                    filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.2))',
                  }}
                />
                {/* Shine effect */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/20 to-transparent"></div>
              </div>

              {/* Character name */}
              <div className="text-center">
                <div className="font-bold text-gray-900 text-lg mb-1">
                  {char.name}
                </div>
                <div className={`text-xs font-medium bg-gradient-to-r ${char.color} bg-clip-text text-transparent`}>
                  Tooth Hero
                </div>
              </div>

              {/* Selected indicator */}
              {userData.selectedCharacter === char.id && (
                <div 
                  className="absolute -top-2 -right-2 w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center animate-bounce"
                  style={{
                    boxShadow: '0 4px 12px rgba(124, 58, 237, 0.4)',
                  }}
                >
                  <Check className="w-6 h-6 text-white" strokeWidth={3} />
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Continue button */}
      <div className="p-6 pt-4">
        <button
          onClick={handleContinue}
          disabled={userData.selectedCharacter === null}
          className={`w-full h-16 rounded-2xl font-bold text-lg transition-all transform ${
            userData.selectedCharacter !== null
              ? 'bg-gradient-to-r from-purple-600 to-purple-500 text-white hover:scale-105 active:scale-95'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
          style={
            userData.selectedCharacter !== null
              ? {
                  boxShadow: '0 8px 24px rgba(124, 58, 237, 0.3), 0 4px 12px rgba(124, 58, 237, 0.2)',
                }
              : undefined
          }
        >
          {userData.selectedCharacter !== null ? '🚀 Start Your Adventure' : 'Choose a Hero First'}
        </button>
      </div>
    </div>
  );
}