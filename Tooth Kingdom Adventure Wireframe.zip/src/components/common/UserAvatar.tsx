import React from 'react';

const characterData = [
  { 
    id: 1, 
    name: 'Luna', 
    color: 'from-purple-400 to-pink-400', 
    image: 'https://images.unsplash.com/photo-1758179760575-deee2f7b518e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGFuaW1lJTIwY2hhcmFjdGVyJTIwcHVycGxlJTIwcGlua3xlbnwxfHx8fDE3NjkxNTE2OTN8MA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  { 
    id: 2, 
    name: 'Max', 
    color: 'from-blue-400 to-cyan-400', 
    image: 'https://images.unsplash.com/photo-1586374579358-9d19d632b6df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGNoYXJhY3RlciUyMGJveSUyMGJsdWV8ZW58MXx8fHwxNzY5MTUxNjk4fDA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  { 
    id: 3, 
    name: 'Mia', 
    color: 'from-pink-400 to-rose-400', 
    image: 'https://images.unsplash.com/photo-1603201401293-040c048d7a00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGFuaW1lJTIwZ2lybCUyMGNoYXJhY3RlciUyMHBpbmt8ZW58MXx8fHwxNzY5MTUxNjk0fDA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  { 
    id: 4, 
    name: 'Zara', 
    color: 'from-amber-400 to-orange-400', 
    image: 'https://images.unsplash.com/photo-1762359853028-e9b61ed96114?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGFuaW1lJTIwY2hhcmFjdGVyJTIwb3JhbmdlJTIwYWN0aW9ufGVufDF8fHx8MTc2OTE1MTY5NXww&ixlib=rb-4.1.0&q=80&w=1080'
  },
  { 
    id: 5, 
    name: 'Kai', 
    color: 'from-indigo-400 to-purple-400', 
    image: 'https://images.unsplash.com/photo-1639094134125-16f32dfe19cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzZCUyMGFuaW1lJTIwY2hhcmFjdGVyJTIwcHVycGxlJTIwZmFudGFzeXxlbnwxfHx8fDE3NjkxNTE2OTV8MA&ixlib=rb-4.1.0&q=80&w=1080'
  },
];

interface UserAvatarProps {
  characterId: number | null;
  size?: 'small' | 'medium' | 'large' | 'xlarge';
  showBackground?: boolean;
  className?: string;
}

export function UserAvatar({ 
  characterId, 
  size = 'medium', 
  showBackground = true,
  className = '' 
}: UserAvatarProps) {
  const character = characterData.find(c => c.id === characterId);
  
  if (!character) {
    return null;
  }

  const sizeClasses = {
    small: 'w-12 h-12',
    medium: 'w-20 h-20',
    large: 'w-32 h-32',
    xlarge: 'w-48 h-48'
  };

  const sizeClass = sizeClasses[size];

  if (showBackground) {
    return (
      <div 
        className={`${sizeClass} bg-gradient-to-br ${character.color} rounded-full flex items-center justify-center overflow-hidden ${className}`}
        style={{
          boxShadow: '0 6px 20px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.08)',
        }}
      >
        <img 
          src={character.image} 
          alt={character.name}
          className="w-full h-full object-contain scale-110"
        />
      </div>
    );
  }

  return (
    <div className={`${sizeClass} ${className}`}>
      <img 
        src={character.image} 
        alt={character.name}
        className="w-full h-full object-contain"
      />
    </div>
  );
}

export function getCharacterName(characterId: number | null): string {
  const character = characterData.find(c => c.id === characterId);
  return character?.name || 'Hero';
}

export function getCharacterColor(characterId: number | null): string {
  const character = characterData.find(c => c.id === characterId);
  return character?.color || 'from-gray-400 to-gray-500';
}